#!/bin/bash
echo "🔁 Restoring system config from $1..."
tar -xzvf "$1" -C /
echo "✅ Restore complete. Consider rebooting or restarting services."
